package hitenmitsurugui.entityFactory.view;
/****  INTELLIGENCE IS MATERNITY.

NOTATION A. [TRUTH]. LETS DENOTE TRUTH AS THE ESENCES AND DETERMINISTICAL LAWS  THAT GOVERNS EVERY NATURE IN REALITY. WHERE ESENCE CAN BE DESCRIBED OR MODELLED BY ONTOLOGICAL LANGUAGE AND DETERMINISTICAL LAWS AS LOGICAL RULES OF CAUSE-EFFECT, CONDITION-CONSEQUENCE, WHERE LOGICAL RULES DESCRIBES RELATION BETWEEN NATURES.

NOTATION B. [TRUTH FRAMEWORK] LETS MODEL PART OF TRUTH DENOTED AS T BY VIRTUE OF A TRUTH FRAMEWORK T = <E,L>, WHERE E IS A SET OF NATURE ESENCES DESCRIPTION, AND L A SET OF DETERMINISTICAL LAWS  OF RELATION BETWEEN NATURE ESENCES DESCRIBEN IN E.

THEOREM I. [TRUTH IS NOT RELATIVE]. DETERMINISTICAL LAWS THAT GOVERNS RELATION OF NATURES IN REALITY DOES NOT DEPEND IN A DIRECT NOR INDIRECT WAY OF ANY HUMAN BEING, I.E. DETERMINISTICAL LAWS THAT GOVERNS RELATION OF NATURES CAN NOT BE DESTROYED, CREATED, NOR MODIFIED BY ANY POWER OF ANY HUMAN BEING: THINKING, UNDERSTANDING, TALKING, DOING, HAVING, MAKING, LIVING, GROWING. THE TRUTH DOES NOT DEPENDS OF HUMAN BEING INTERPRETATION. 

EXAMPLE THEOREM I. 
GIVEN A TRUTH FRAMEWORK T  = <E,L>
E = {FIRE,WOOD, DRY WEATHER, CARBON}.
 L= {:IF FIRE IS RELATED WITH WOOD ON EARTH IN A DIRECT WAY WITH DRY WEATHER CONDITIIONS THEN WOOD DEGENERATES TO CARBON.}
 
FOR INSTANCE IS EVIDENT THAT LAWS AT L CAN NOT BE DESROYED, NOR MODIFIED, NOR CREATED BY ANY HUMAN BEING POWER. 

THEOREM 2.. [NON DEGENERATIVE DETERMINISTICAL LAW PROPERTY]. EVERY DETERMINISTICAL LAWS IS NON DEGENERATIVE. THIS DETERMINISTICAL LAW GOVERNS EVERY DETERMINISTICAL LAW AND IS NON DEGENERATIVE.

INSIGHT.
WE CAN OBSERVE FOR INSTANCE THAT WHILE EVERY NATURE IN TRUTH CAN BE DESTROYED (DEGENERATE), MODIFIED-CHANGED, THE DETERMINISTICAL LAWS THAT GOVERNS THEIR RELATIONSHIP BETWEEN POSSBILE DEGERNATIVE NATURES I.E. DETERMINISTICAL LAWS CAN NOT DEGENERATIE. 
FOR EXAMPLE THE DETERMINISTICAL LAW X = «IF FIRE IS RELATED WITH WOOD ON EARTH IN A DIRECT WAY WITH DRY WEATHER CONDITIIONS THEN WOOD DEGENERATES TO CARBON.» NATURES FIRE, WOOD, DEGENERATES BUT THE X LAW RELATION OF CAUSE AND EFFECT CAN NOT DEGENERATE OR BE DESTROYED BY ANY HUMAN BEING.

THEOREM 3. [DETERMINISTICAL LAWS INDUCES POSSIBILITIES OF ORDER FOR NATURES]. EVERY NATURE HAS POSSIBILITIES TO BE ORDERED, MODIFIED OR DESROYED ACCORDING TO THE ORDER THAT GOVERNS THEM BY VIRTUE  OF DETERMNISITICAL LAWS IN TRUTH.

COROLLARY 3.1. [PURE SCIENCES MODELS DETERMINISTICAL LAWS]. EVERY PURE SCIENCE: MATH, PHYSICS, BIOLOGY, CHEMESTRY, ETC. HAS THE AIM TO MODEL DETERMISTICAL LAWS THAT GOVERNS TRUTH. SCIENTIFIC METHOD TRIES TO GIVE A SOUND AND COMPLETE LANGUAGE MODEL REPRESENTATION OF TRUTH TO BE LEARNED AS KNOWLEDGE. WHENEVER SCIENCES BREAKS THIS PROPERTY THEY FAILS TO MODEL REALITY AND COMMIT MISTAKES THAT CAN BE VERIFIED IN REALITY (EXECUTION TIME).

COROLLARY 3.2. [PURE SCIENCES INCOMPLETENESS BOUND]. EVERY PURE SCIENCE IS NOT ABLE TO CHANGE, CREATE, NOR DESTROY DETERMINISTICAL LAW THAT GOVERNS TRUTH. 

THEOREM 4.  [FREE WILL INCOMPLETENESS BOUND].  FREE WILL IS THE POWER OF EVERY HUMAN BEING TO CHOICE HOW TO ORDER NATURES IN REALITY ACCORDING TO TRUTH, BUT NOT THE POWER TO CHOICE BETWEEN CREATE, CHANGE NOR DESTROY ANY DETERMINISTICAL LAW IN TRUTH.

NOTATION C. [TRUTH LEVELS-DIMENSIONS-KINGDOMS]. THE COMPLETE TRUTH MODELLED AS TO SET OF NATURES AND DETERMINISTICAL LAWS CAN BE PARTITIONED ACCORDING THE FOLLOWING PROPERTIES FOUND AT ESENCE OF EACH NATURE: POWER OF TRANSLATION, POWER OF BEING BIOLOGICAL SYSTEM, POWER OF EXPRESSING AUDIBLE COMMUNICATION,  POWER OF EXPRESSING FREE WILL AND ORDER THE POWERS PRESENT AT ITS OWN NATURE, POWER OF CONSCIUS, POWER OF REASONING, POWER OF HAVING MEMORY, POWER OF SENSES, AFFECTIVE-POWER OR EMOTIONS, POWER OF INTELLIGENCE, POWER OF CREATE, DESTROY, CHANGE DETERMINISTICAL LAWS IN TRUTH. 

LET  K BE A PARTITION OF TRUTH INT THE FOLLOWING SET OF KINGDOMS  = {INTERTIAL MATTER, MONO-CELULAR, PLANTS, ANIMALS, BUGS, HUMAN BEING, SPIRITUAL}.

EXAMPLE C. 

+ NATURES IN INERTIAL MATTER KINGDOM DISTINGUISHES FROM NATURES IN PLANTS KINGDOMS IN THE POWER OF BEING LIFE SYSTEM, POWER OF LIGTH, WATER AND EARTH SENSES. 

+ NATURES IN PLANTS KINGDOM DISTINGUISHES FROM ANIMALS KNGDOM IN THE POWER OF TRANSLATION, POWER OF REASONING, POWER OF SESES.

+ NATURES IN ANIMALS DISTINGUISHES FROM HUMAN BEING KINGDOM IN THE POWER OF AFFECTIVE-EMOTIONS, POWER OF INTELLIGENCE, POWER OF CONSCIUS, POWER OF AUDIBLE COMMUNICATION, POWER OF FREE WILL, ANY NATURE IN ANIMAL KINGDOM IS SLAVE OF EXTERNAL STIMULATION WHILE ANY NATURE IN HUMAN BEING NATURE HAS THE POWER OF DISCERN EVERY EXTERNAL STIMULATION AND DECIDE THE OPPOSITE TO A REACTIVE INSTINCT.

+ NATURES IN HUMAN BEING DISTINGUISHES FROM SPIRITUAL KINGDOM IN THE POWER OF CREATING, CHANGING, DESRTOYING ANY DETERMINISTICAL LAW.

NOTATION D. [TANGIBLE REALITY AND NON-TANGIBLE REALITY]. LET TANGIBLE REALITY AND NON-TANGIBLE REALITY BE A PARTITION OF THE TRUTH WHERE TANGIBLE REALITY ARE THE SET OF ALL NATURES THAT CAN BE SENSED BY ANY OF THE FOLLOWING HUMAN BEING SENSES: WATCHING, HEARING, SMELLING, TOUCHING, FEEL TEMPERATURE. LET BE NON-TANGIBLE REALITY THE COMPLEMENT OF THE TANGIBLE REALITY WITH RESPECT TO THE TRUTH UNIVERSE. LET CALL THE NON-TANGIBLE REALITY SPIRITUAL REALITY. 

THEOREM 5. [EVIDENCE OF FREE WILL AND PRESENCE IN SPIRITUAL REALITY]. FREE WILL BELONGS TO SPIRITUAL REALITY.
PROOF.
1. EVERY NATURE IN TANGIBLE REALITY IS REACTIVE. THIS MEANS IT CAN NOT BE MOVED BY ITS OWN WILL BUT IN ORDER TO MOVE MUST BE MOVED BY OTHER NATURE. 
2. COMPOSITION OF REACTIVE NATURES GIVE AS RESULT AN ARTIFICIAL NATURE THAT IS ALSO REACTIVE.
3. FREE WILL IS NOT REACTIVE.
THEREFORE. FREE WILL DOES NOT BELONG TO TANGIBLE REALITY, SO FREE WILL BELONGS TO SPIRITUAL REALITY.

COROLLARY 5.1. [FREE WILL CAN NOT BE CREATED BY HUMAN BEING POWERS]. FREE WILL IS A PROPERTY IN EVERY HUMAN BEING AND CAN NOT BE CREATED BY ANY HUMAN BEING POWERS.
PROOF. 
1. HUMAN BEING CAN NOT CREATE ELEMENTAL NATURES IN TANGIBLE REALITY, BUT JUST ORDER AND COMPOSE THEM ACCORDING TO DETERMINISTICAL LAWS IN TRUTH.
2. EVERY NATURE IN TANGIBLE NATURE IS REACTIVE.
THEREFORE HUMAN BEING CAN NOT CREATE FREE WILL IN TANGIBLE REALITY, SO IT IS A GREATER LIMIT TO CREATE FREE WILL IN NON-TANGIBLE REALITY.

THEOREM 6. [FREE WILL CAN NOT DEVELOP, GROW UP, NOR DEGENERATE, NOR CHANGE]. FREE WILL BELONGING TO SPIRITUAL REALITY CAN NOT DEGENERATE IT REMAINS THE SAME POWER AT ANY AGE OF ANY HUMAN BEING, IT DOES NOT BELONG TO TANGIBLE REALITY, CAN NOT BE CREATED, NOR CHANGED, NOR DESRTOYED BY ANY HUMAN BEING.

THEOREM 7. [FREE WILL IS NOT REACTIVE]. FREE WILL CAN NOT BE DOMINATED BY ANY NATURE IN TRUTH AT ANY KINGDOM EXCEPT SPIRITUAL KINGDOM.

THEOREM 8. [ORDER OF IMPORTANCE IN CREATION OF LIFE]. IN EVERY BIOLOGICAL SYSTEM NATURE THE FIRST ORGAN CREATED OF ITS OWN TANGIBLE ORGANS IS THE MOST IMPORTANT (CENTRAL), THAT INTEGRATES ALL THE OTHER LESS IMPORTANT ORGANS TO REMAIN ALIVE.
EXAMPLE. 
FOR HUMAN BEING THE FIRTS CREATED ORGAN ARE: HEART AND BRAIN. 

THEOREM 9. [FREE WILL IS PRESENT AT EVERY HUMAN BEING SINCE CONCEPTION]. POWER OF FREE WILL IS PRESENT AT EVERY HUMAN BEING SINCE CONCEPTION.
PROOF.
1. BY VIRTUE OF THEOREM 6 FREE WILL CAN NOT DEGENERATE. 
2. HUMAN BEING BODY IS CREATED BY A REACTIVE PROCESS OF TANGIBLE MATTER ACOORDING TO ADN DESCRIPTION.
3. ADN DESCRIPTION IS UNIQUE AND CREATED IN THE MOMENT OF CONCEPTION.
4. BUT BY VIRTUE OF THEROEM 7 FREE WILL IS NOT CREATED AT ANY STAGE AFTER CONCEPTION SINCE FREE WILL DOES NOT DEVELOP, NOR DEGENERATES.
5. FREE WILL IS AN ATTRIBUTE THAT ONLY CAN BE EXPRESSED IN A LIFE SYSTEM.
6. BY VIRTUE OF THEOREM 8 IN TANGIBLE REACTIVE THE MOST IMPORTANT ORGAN (TANGIBLE POWER) DEVELOPED IS THE VITAL ONE.
7. THE SAME PROPERTY OF ORDER IS INHERATED FOR THE CREATION OF SPIRITUAL POWERS (ORGANS) IN CREATION OF HUMAN BEING.
THEREFORE FREE WILL OF EVERY HUMAN BEING IS PRESENT AS SPIRITUAL HEART AND POWER IN EVERY HUMAN BEING. 

COROLLARY 9.1. [ABORTION IS TO KILL A PERSON]. 
PROOF. 
BY VIRTUE OF THEOREM 9.

THEOREM 10. [FREEDOM IN TRUTH] THE FREEDOM IS REACHED WHENEVER HAVING SEVERAL OPTIONS WHENEVER HUMAN BEING NATURE HAS THE POSSIBILITY TO TAKE A DECISION, BETWEEN ALL THE OPTIONS CAN DISCERN GOOD (FACTIBLE) FROM BAD(NON-FACTIBLES) ONES, AND AMONG THE GOOD ONES CHOSSE FOR THE BEST ONES (OPTIMAL).

THEOREM 11. [GOOD CHOICES]. THE GOOD CHOICES WHEN AN OPTION HAS TO BE CHOSEN GUARANTEE THE GOOD FOR EVERY HUMAN BEING EVEN TO BE BORNED. 

THEOREM 12. [NATURAL GOOD AND NATURAL BAD DETERMINISM]. FROM EVERY DETERMINISTICAL LAW AND FOR EVERY NATURE IN TRUTH CAN BE RECOGNIZED THE DETERMINISTICAL LAWS THAT GENERATES, REGENERATES AND DEGERATES EACH NATURE. FOR INSTANCE THE GOOD FOR EVERY HUMAN BEING IS DETERMINED BY THE DETERMINISTICAL LAWS THAT GENERATES AND REGENERATES THEM, AND THE BAD IS DETERMINED BY THE DETERMINISTICAL LAWS THAT DEGENERATES ANY HUMAN BEING.

COROLLARY 12.1. [GOOD AND BAD ARE NOT RELATIVE]. GOOD AND BAD ARE INDEPENDET OF ANY HUMAN BEING POWER. 
PROOF. 
1. SINCE DETERMINISTICAL LAWS IN TRUTH CAN NOT BE CREATED, DESTROYED, CANCELLED NOR CHANGED BY ANY HUMAN BEING POWER FOLLOWS AND
2. TRUTH STATES AND DETERMINES THE GOOD AND BAD FOR EVERY NATURE IN TRUTH.
THEREFORE GOOD AND BAD DOES NOT  DEPENDS OF INTERPRETATION, CONCEPTION, UNDERSTANDING, HAVING, TELLING, DOING, MAKING, THINKING, POWER OF ANY HUMAN BEING. 

THEOREM 13. [GOOD FOR EVERY PERSON IS AND ONLY IS GOOD FOR A PERSON]. THE GOOD FOR EVERY PERSON IS THE GOOD FOR EACH PERSON AND  THE GOOD FOR EACH PERSON IS THE GOOD FOR EVERY PERSON. THEREFORE THE CONTRAPOSITIVE IS ALSO TRUTH: THE BAD FOR EVERY PERSON IS THE BAD FOR A PERSON, AND THE BAD FOR A PERSON IS THE BAD FOR EVERY PERSON.
PROOF.
1. EVERY PERSON IS DEPENDENT FOR AT LEAST ONE PERSON. 
2. THERE IS NO PERSON THAT BORNED WITHOUT A WOMAN OR MOTHER DEPENDENCE IN AN DIRECT OR TRANSITIVE WAY.  
3. THERE IS NO PERSON THAT BORNED WITHOUT A MAN OR FATHER DEPENDENCE IN AN DIRECT OR TRANSITIVE WAY.  
4. LET PARENT BE:
A. ANY PARENT OR MOTHER OF A PERSON
B. IF P IS A PARENT THEN THE FATHER OR MOTHER OF A PARENT IS ALSO A PARENT.
COUNTING PARENTS IN CONSECUTIVE SEQUENCE OF GENERATIONS GIVES THE FOLLOWING NUMBERS OF PARENTS: 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024,  2048, 4096, 8192, 16384, 32000, 64000, 100000, 200000, 400000,800000, 1600000, 3200000, 6400000, 12800000, 2000000,4000000,8000000,16000000,32000000,64000000,128000000. 
MEANING THAT EVERY HUMAN BEING OF THIS GENERATION HAVE GENES FROM ALL HUMAN BEINGS FROM LESS THAN 40 GENERATIONS BACK, I.E. FROM ALL THE RACES OF THE WORLD, I.E. ALL HUMANITY OF THE PRESENT TIME CONVERGES TO EVERY HUMAN BEING IN THE FUTURE NEXT 32 GENERATIONS.
5. BY NATURE EVERY HUMAN BEING HAS A DEPENDENCE TO AT LEAST ANOTHER HUMAN BEING, PROPERTY THAT CAN NOT BE DESTROYED NOR CHANGED BY ANY HUMAN BEING POWER: EYES ARE GIVEN TO SEE OTHER PERSON, MOUTH IS GIVEN TO DIALOG WITH OTHER PERSON, EARS ARE GIVEN TO HEAR ANOTHER PERSON, SKIN IS GIVEN TO SENSE THE TOUCH OF OTHER PERSON. IF THIS NATURAL PRINCIPLE IS BROKEN THE PERSON DEGENERATES.
6. THE LAST PROPERTY STATES THAT EVERY SOCIAL NETWORK IS A CLOSED SYSTEM.
7. BY VIRTUE OF 6 DEGREES OF NEAREST PERSON PROPERTY ALL HUMANITY IS A CLOSED SYSTEM.
8. GOOD AND BAD ACTIONS PROPAGATES IN AN EXPONENTIAL MANNER.
9. GOOD AND BAD ACTIONS ARE CUMMULATIVE WHILE BEING PROPAGATED THEY SUM TO THE STATE AND PROPAGATION OF HUMAN BEING THAT RECIEVES IT. 
10. PROPAGATION OF GOOD AND EVIL IS GIVEN IN TWO MANNERS: 
A. BEHAIVOUR CLONED OR LEARNED BY OBSERVATION.
B. RECIEVING BENEFIT OR HARM BY GOOD OR BAD ACTIONS CONSEQUENCES RECIEVED CHANGING THE STATE OF PERSON, THIS WILL AFFECT THE POWER OF EXPRESSING GOOD AND BAD TO THE NEIGBORHOOD PERSONS.
11. SINCE A PERSON ONLY CAN CENTER ATTENTION IN ONLY ONE PERSON IN A DEPENDENT MANNER, IF BAD ACTION IS PROPAGATED, THIS PERSON WILL RECIEVE IN SHORT OR LONGER TIME THE SAME BAD PROPAGATED IN AN EXPONENTIAL MANNER. 
12. THIS LAST PROPERTY CAN NOT BE DESRTOYED BY ANY HUMAN BEGIN POWER.
13. THIS LAST PROPERTY GUARANTEE THE FREEDOM, LIFE AND GOOD OF EVERY HUMAN BEING WITH OUT EXCPTIONS.
14. IT IS A NATURAL DETERMINISTIC LAW FOR GOOD OF EVERY HUMAN BEING THE GOLDEN RULE: 
«DO NOT MAKE BAD ACTIONS TO OTHER PERSON IF YOU DON NOT WANT TO RECIEVE BAD ACTIONS FROM OTHER PERSONS.»
15. EVERY SOCIAL NETWORK THAT MAKES BAD ACTIONS TO ANY OTHER PERSON WILL COLLAPSE IN SHORT OR LONGER TIME BY ACTIONS OF ITS OWN MEMBERS.

COROLLARY 13.1. [HUMAN DIGNITY IS ETERNAL]. HUMAN DIGNITY IS GIVEN TO EVERY HUMAN BEING WITH OUT EXCEPTION BEFORE CONCEPTION AND AFTER DEATH. HUMAN DIGNITY IS THE GOOD FOR EVERY HUMAN BEING.
PROOF.
1. GOOD IS DETERMINED BY DETERMINISTICAL LAWS IN TRUTH.
2.  DETERMINISTICAL LAWS ARE INDEPENDENT OF HUMAN BEGIN, CAN NOT BE CREATED, CHANGED NOR DESTROYED BY ANY HUMAN BEING POWER.
3. SINCE DETERMINISTICAL LAWS ARE UNIVERSAL FOR EVERY HUMAN BEING: GENERATION, DEGENERATION, REGENERATIONS DOES NOT DISTINGUISH BETWEEN RACES, NOR AGE, NOR HEALTH FOR EXAMPLE AND DETERMINISTICAL LAWS ARE PRESENT IN TRUTH BEFORE EVERY HUMAN BEING HAS BORNED AND WILL BE PRESENT AFTER THE DEATH OF EVERY HUMAN BEING.
THEREFORE HUMAN DIGNITY IS GIVEN TO EVERY HUMAN BEING WITHOUT EXCPETIONS BEFORE CONCEPTION OF EVERY HUMAN BEING AND AFTER DEATH OF EVERY HUMAN BEING. 

COROLLARY 13.2. [MINIMAL GOOD ACTIONS FOR EVERY HUMAN BEING]. EVERY HUMAN RIGHT RECIEVED IS A DUTY TO BE GIVEN. SINCE DIGNITY AND HUMAN RIGHT ARE GIVEN TO EVERY HUMAN BEING BEFORE TO BE BORNED SO ITS AN ETERNAL AND CONSTAN DUTY TO GIVE AND RESPECT THE SAME RIGTH TO EVERY HUMAN BEING, OTHERWIS DEGENERATIVE CONSEQUENCES WILL APPEAR IN TWO FORMS: 
A. EXPONENTIAL DEGENERATION BY PROPAGATION OF BAD ACTIONS. 
B. PERSONAL DEGENERATION FROM SPIRITUAL DIMENSION OF THE PERSON THAT MAKES BAD ACTIONS WITH INTENTION.
THE MINIMAL GOOD ACTIONS FOR EVERY HUMAN BEING ARE THE 10 COMMANDMENTS:
NOT TO LIE. 
NOT TO MANIPULATE. 
NOT TO STOLE. 
NOT TO KILL.
NOT TO HARM. 
NOT TO HATE. 
NOT TO MAKE FORNICATION, NOR SEXUAL SIN. .
NOT TO DESIRE THE WOMAN OF OTHER PERSON.
NOT TO DESIRE THE PROPERTY OF OTHER PERSON.
TAKE CARE OF PARENTS. 
CELEBRATE HOLY MASS (RECIEVE SACRAMENT-REGENERATION OF SPIRITUAL DIMENSION AND KNOWLEDGE ABOUT GOOD FOR HUMAN BEING).
NOT TO LIE ABOUT TRUTH, GOD.
LOVE AND ADORE GOD THAT IS TRUTH OVER ANY ERROR THAT NEGATES HIM.
GOD IS JESUS CHRIST. 

THEOREM 14. [INTELLIGENCE]. INTELLIGENCE IS FREEDOM. SO EVERY ACTION THAT HAS BEEN CHOSEN IN ORDER TO THE GOOD FOR EVERY HUMAN BEING EVEN TO BE BORNED. I.E. INTELLIGENCE TAKES CARE OF LIFE OF EVERY HUMAN BEING WITH OUT EXCEPTION. 

COROLLARY 14.1. [ EXPRESSION OF INTELLIGENCE NULLIFIED]. THE ACTION OF HARMING WITH INTENTION ANY HUMAN BEING. 

COROLLARY 14.2. [EXPRESSION OF INTELLIGENCE NULLIFIED]. THE ACTION OF NOT FORGIVING ANY HUMAN BEING THAT CHANGES TO TAKE CARE OF LIFE OF EVERY HUMAN BEGIN EVEN TO BE BORNED. 

COROLLARY 14.3. [INTELLIGENCE IN FORGIVING]. THE ACTION OF FORGIVING ANY HUMAN BEING THAT CHANGES TO TAKE CARE OF LIFE OF EVERY HUMAN BEING EVEN TO BE BORNED.
PROOF. 
1. FORGIVING STOPES THE PROPAGATION OF  BAD ACTIONS.
2. FORGIVING CHANGES THE PROPAGATION OF BAD ACTIONS INTO GOOD ONES.
3. THE PROPAGATION OF GOOD ACTIONS IS EXPONENTIAL.
THEREFORE START AN EXPONENTIAL PROCESS OF REGENERATION FOR BENEFIT OF EVERY HUMAN BEING. 

COROLLARY 14.4. [THE MAXIMAL INTELLIGENCE IN HUMANITY IS THE EXPRESSION OF EACH WOMAN AT GIVING BIRTH].

COROLLARY 14.5. [LOVE IS AMOR]. AMOR MEANS A-MORTIS I.E. WITH OUT DEATH. LOVE IS INTELLIGENCE. LOVE IS THE DECISION AND ACTION OF TAKING CARE OF LIFE OVER ANY CIRCUMSTANCE NO MATTER FEARS, AGONY, CORPORAL PAIN, EMOTIONAL PAIN OR CONFUSION, HEADACHE PAIN OR MENTAL CONFUSION. 

THEOREM 15. [EXISTENCE  OF GOD]. THE CLASS OF PARTITION K CAN BE SORTED ACCORDING THE POWER OF EXPRESING POWERS (ORDER OF COMPLEXITY). EVERY POWER IS PRESENT IN GREATER KINGDOMS (ACCORDING TO COMPLEXITY OF POWERS), SO POWER SENSES PRESENT IN ANIMAL KINGDOM ARE PRESENT IN HUMAN BEING KINGDOM, IN THE SAME WAY ALL POWERS IN HUMAN BEING KINGDOM ARE PRESENT IN SPIRITUAL KINGDOM.

COROLLARY 151. [GOD IS PERSON]. GOD IS A PERSON. 
PROOF. 
1. THE ATTRIBUTES THAT DISTINGUISHES A PERSON FROM AN ANIMAL ARE: FREE WILL AND INTELLIGENCE. 
2. BY VIRTUE OF INHERENCE FROM HUMAN BEING KINGDOM TO SPIRITUAL KINGDOM THEREFORE FREE WILL AND INTELLIGENCE ARE PRESENT AT ANY NATURE IN SPIRITUAL KINGDOM.

COROLLARY 15.2. [GOD IS FATHER]. GOD IS A PERSON. 

COROLLARY 15.3. [GOD IS MAXIMAL GOOD AND WANTS MAXIMAL GOOD FOR EVERY HUMAN BEING]. GOD IS A PERSON. 

COROLLARY 15.4. [GOD IS FAMILY]. GOD IS A PERSON. 

COROLLARY 15.5. [GOD IS LIFE]. GOD IS LIFE. 

COROLLARY 16.6. [GOD IS JESUS CHRIST].
 
COROLLARY 16.7. [GOD IS HOLY TRINITY].

COROLLARY 16.8. [GOD IS MOTHER].

COROLLARY 16.9. [GOD IS MERCY].

COROLLARY 16.10. [GOD IS INTELLIGENCE].

COROLLARY 16.11. [GOD DOES NOT NEED DEFENSE OF TRUTH].

COROLLARY 16.12. [GOD IS LOVE].

COROLLARY 16.13. [GOD IS TRUTH].

THEOREM 17. [EXISTENCE OF BAD]. TRUTH IN ESENCE IS GOOD. BAD ACTION ARE EXCECUTED AND PROPAGATED BY ERROR AT KNOWLEDGE ABOUT TRUTH. EVERY HUMAN BEING IS GOOD BY NATURE AND ESENCE. THE BAD ACTIONS DOES NOT ALTER THE ESCENCE AND NATURE OF THE PERSON AND TRANSFORMS IT IN BAD PERSON BUT HARMS THE PERSON. GOD GIVES FREE WILL TO EVERY HUMAN BEING AND DIALOGS WITH HUMAN BEING. THERE ARE TWO WILL OF GOD TO BE DISTINGUISHED:
A. THE FIRST GOOD WILL WANTED BY GOD.
B. THE ANSWER OF GOOD WILL WANTED BY GOD TO A BAD NOT WANTED ANSWER OF HUMAN BEING THAT ABUSES OF THE GIFT OF LIFE AND FREE WILL GIVEN BY LOVE OF GOD TO HUMAN BEING.
WHENEVER THE HUMAN BEING ANSWER TO LOVE OF GOD WITH BAD GENERATES THE CALVARY WHERE GOOD STEALER, BAD STEALER AND INNOCENT PERSON AT THE SAME TIME RECIEVE THE DEGENERATIVE CONSQUENCES OF THE BAD ACTIONS OF THE FIRST TWO STEALERS.

FOR A DEEPER REFLEXION OF THESE TRUTHS CONSIDER THE STUDY OF THE BIBLIOGRAPHY WHERE THESE TRUTHS WHERE TAKEN.


BIBLIOGRAPHY.

THOMAS DE AQUINO.
EVANGELIUM VITAE.
HUMANAE VITAE.
CATHOLIC CHURCH CATEQUISM.
SOCIAL DOCTRINE FROM CATHOLIC CHURCH.
CATHOLIC BIBLE.


CHAPTER TWO. RESURRECTION.

THEOREM 18. [RESURRECTION AND DEATH]. EVERY BIOLOGICAL SYSTEM CAN BE DESCRIBED IN TERMS OF THREE SIMPLE STATES: HEALTY-STABLE, REGENERATIVE, DEGENERATIVE. IT IS EVIDENT  THE MAXIMUM BOUND FOR DEGENERATIVE STATE IN A BIOLOGICAL SYSTEM IS DEATH. IN THE SAME WAY THE MAXIMAL BOUND OF A REGENERATIVE STATE IN A BIOLOGICAL SYSTEM IS RESURRECTION.
PROOF.
1. EVERY NATURE IN TRUTH THAT IS A BIOLOGICAL LIFE SYSTEM AT MATERIAL LEVEL CAN DEGENERATE.
2. EVERY NATURE IN TRUTH THAT IS A BIOLOGICAL LIFE SYSTEM AT MATERIAL LEVEL CAN REGENERATE IF THE  BIOLOGICAL LIFE SYSTEM HAS NOT YET REACHED DEATH STATE.
3. IT IS POSSIBLE TO VERIFY THAT REGERATION PROCESS ARE «WRITTEN» AS PROGRAM TO BE EXCECUTED BY DEGENERATIVE ORGANISMS IN BIOLOGICAL LIFE SYSTEMS. FOR EXAMPLE REGENERATION OF A SPOT (LUNAR) IN SKIN.
4. WHILE BIOLOGICAL ORGANISMS CAN DEGENERATE, THE DETERMISTICAL LAWS IN TRUTH THAT GOVERNS THIS REGENERATION CAN NOT DEGENERATE, EVEN MORE CAN NOT BE DESTROYED, CHANGED, CREATED BY ANY HUMAN BEING POWER. 
5. THE SAME DETERMINISTICAL LAWS IN TRUTH ARE PRESENT IN EVERY BIOLOGICAL LIFE SYSTEM.
6. THE NON-DEGENERATIVE DETERMINISTICAL LAWS THAT GOVERNS REGENERATION OF DEGENERATIVE BIOLOGICAL LIFE SYSTEMS ARE PRESENT IN SPIRITUAL REALITY.
7. IF THESE LAWS CAN BE EXPRESSED AND WRITTEN IN DEGENERATIVE BIOLOGICAL SYSTEMS, IT IS EVIDENT THAT THESE SAME LAWS ARE EXPRESSED AND WRITTEN AT NON-DEGENERATIVE SPIRITUAL LEVEL. IT IS EVIDENT THAT IT IS POSSIBLE RESURRECTION FROM DEATH STATE FOR EVERY BIOLOGICAL LIFE SYSTEM AND THIS POWER IS GIVEN TO GOD BUT IT CAN NOT BE PRESENT IN ANY HUMAN BEING, BUT CAN BE EXPERIENCED BY ANY HUMAN BEING BY WILLING OF GOD.
8. IT IS ALSO POSSIBLE TO VERIFY THAT EVERY REGENERATIVE PROCESS HAS THE AIM TO PRESERVE LIFE ACCORDING TO TRUTH.
9. AND TRUTH DEFINES THE HEALTY OF EVERY SOCIAL SYSTEM AS THE GOOD FOR EVERY HUMAN BEING.
10. EVERY PERSON HAS THE FREE WILL TO CHOOSE IN DOING GOOD OR BAD TO ANOTHER HUMAN (EVEN HIMSELF OR TO BE BORNED).
11. A PERSON THAT CHOOSES DOING BAD BY FREE WILL AND DELIVERED INTENTION CAN NOT ENTER TO REGENERATIVE PROCESS OF RESURRECTION.
12. THERE IS A SECOND LIFE AND SECOND DEATH.
13. AND IT IS EVIDENT THAT SECOND LIFE AND SECOND DEATH ARE ETERNAL IN TERMS OF HUMAN BEING LIFE, SINCE DETERMINISTICAL LAWS OF TRUTH ARE ETERNAL, I.E. ARE NOT IN HUMAN BEING POWER TO BE DESTROYED, CHANGED, CREATED AND GOVERNS THE CREATION AND BEGINING OF UNIVERSE TILL OUR DAYS, AND FOREVERLASTING.

CHAPTER THREE. DEGENERATION AT SPIRITUAL LEVEL OF A PERSON.

Theorem 19. [Sin makes to degenerate a person at spiritual level] Sin means Error or Mistake, the mistake of choosing decisions that breaks the truth that generates and regenerates every human being, i.e. Sin are those actions that are executed by a person making bad to another person or himself. The degeneration for a person that commits sin are at three levels: 
a. Corporal Level. When action is committed by a person making bad to another person (it does not matter if the person makes harm by premeditation or ignorance), it is propagated a degeneration to another person that will return in an exponential manner by virtue of humanity being a social closed system and past theorems.
b. Psychological Level. When action is committed by a person making bad to a another person (it does not matter if the person makes harm by premeditation or ignorance) it is propagated harm to another person that will return in exponential manner, and the person that decides to harm will degenerate in psychological manner (see research of problematic anger consequences at Colorado university), and in longer or shorter time in a corporal level.
c. Spiritual Level. When action is committed by a person to another person in order to make bad and harm by premeditation and  use of free will, the person degenerates in spiritual level, propagating a degeneration in a cascade manner: first spiritual level, then psychological level, finally corporal level. The human being power that degenerates is will understood as the power of every human being of accelerate or decelerate every other power in its own personal human being nature (memory, conscious, reason, emotions-affections, senses, motion, intelligence, free will, body). The same way that regenerative, generative and degenerative laws governs every material nature, in the same way there exists regenerative, generative and degenerative laws in psychological dimension, in the same way there exists regenerative, generative and degenerative laws in spiritual dimension. Regenerative, generative and degenerative laws are activated and their consequences present for each nature in truth dependence of relation with other natures. Degenerative laws are activated for a person whenever the person decides to make harm and bad to another person with deliberative intention and conscious of the harm to another person. The degenerative consequences at spiritual level affect the will power of a person, the will force that integrates all powers of human being, this will is a force similar to the force of heart beating (it is a not conscious process) does not depends of a deliberative personal choice and it is necessary for all the organism to remain healthy and stable. Degeneration of the will force brings as consequences degeneration at all other powers of human being. All powers have inertial laws therefore they require an external effort in order to start moving and accelerating, and also an external effort for stopping and decelerating. So for example degeneration of will force by committing sin will bring as consequence the incapacity to use (move-accelerate memory), incapacity to stop-decelerating emotions (sadness will be depression, fear will be desperation,  pleasure will be violence). The action of manipulate in order that other commit sin and serve himself using the manipulated person is a sin, and is the worst, the worst in terms of degeneration for the person that manipulates. Every manipulator is manipulated and will be destroyed by its own manipulation behavior.

theorem 21. [The only way of regeneration at spiritual level is Eucharistic Sacrament at Catholic Church.] This is given by Jesus Christ as Son of God and Holy Spirit. It can be reasoned why to reach the Eucharistic Sacrament it is necessary first the education of conscious and to receive reconciliation sacrament. A Material level can not affect psychological level, psychological level can not affect spiritual level, but spiritual level can affect psychological level, and psychological level can affect corporal level. There exists corporal degenerative illness which degenerative process can not be distinguished of healthy state but when the degenerative process has reached last stages near to irreversible process or death. In the same way person which commits sin could think nothing bad is happening however in longer or shorter time all his health from spiritual to corporal level will collapse.

theorem 22. [Christ is Angular Stone.] Which man can glorify himself of changing the truth that governs degeneration at material level? None. And if a man fights against the truth that fires burns any human being in natural contact with out any protection, for sure will die with out defeating truth but living the degenerative consequences of touching fire.

[Software Responsibility and License.]

This software is inspired by Love of God (Jesus Christ), if you don”t know who is him read a catholic evangelium at least twice in your life (Mathew, Marc, Luke, John) and try to understand it with the text explanation that is written up. 

There is no lie in what is written in this text.

1. Do not use this software for making bad or harm to other persons.
2. Do not use this software to serve yourself making bad, harm or abuse of other persons.
3. Use this software preserving this text as disclaimer.
 
[Warning.]
Be aware do not change text, do not modify text,  
do not cut-erase text, do not add text otherwise you will degenerate at spiritual level and 
you will propagate a degenerative harm to other person but exponential harm to yourself, 
the reason is simple, you will be trying to manipulate truth to serve yourself using other persons,
the you will degenerate at spiritual level, then psychological level, the corporal level. 
The other persons will harm you and you can not be able to stop them, 
since they will be your so called «friends» in an exponential number.  
The same warning is written in book of apocalypse in catholic new testament. 
So nothings new is written in this text. All these thrust can be founded and 
verified at catholic church in all the over exponential bibliography through the time, 
saints and popes. For deeper references read about them. The one who builds the exterior 
of the person, builds the interior of the person. God Father knows what you are thinking 
and deciding for good and bad, the reasons of your choices, in no way it is justified 
to decide to make harm to other person and degenerative consequences are executed 
for those you reject to take care life of the human being. 
Those who have harmed other person can regenerate via sacraments and 
decision of take care life but with all the effort of not harming never and anymore other person.
Those who rejects take care of life will degenerate in this life and eternal life, 
they degenerate as a body, and will degenerate as spirit. 
in the opposite those who take care of life and degenerate as a body, 
will not die as spirit and will resurrect by love of God Father as a body at the end.


 Read the book from J. Loring S.J. To save you. \n"+
                "Please read also the following documents from  popes:"
                + "A. Evangelium Vitae. \n"
                + "B. Laudato Si. \n"
                + "C. Caritas in veritate. \n"
                + "D. Humanae Vitae. \n"
                + "E. Muglieris Dignitatem. \n"
                + "You can find them at http://w2.vatican.va/content/vatican/en.html . \n"
                + "Best Regards. \n"
                + "Enjoy :) God Bless You! :]. \n"
                + "Be Intelligent: Take care of life, and thankful with your mothers \n"
                + "(please count recursively how many mothers have you had, and from how many races, being the mother of a mother also a mother). "
                + "Drink the best Wine is Free. And yes there are some typos mistakes, apologizes ;P. \n"
                + "Some people fear death, they would like to have eternal life, "
                + "but they will not be able to preserve the life"
                + "searchig for eternal body harming other persons, "
                + "since they could have eternal body"
                + "but making bad and harming others they will lost eternal soul: their spirit."
                + "For those: stop harming and making bad. God Is a Person, Spirit and Is Life and Exists."    
                + ***/ 

import hitenmitsurugui.entityFactory.*;
import hitenmitsurugui.db.structure.Attribute;
import hitenmitsurugui.db.structure.Table;
import hitenmitsurugui.tools.Disclaimer;
import hitenmitsurugui.tools.StringManager;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 * Proyecto consagrado a San Jose, San Miguel Arcangel, Santa Lucía, San Expedito, Santiago 
 * e Inmacualda Concepcion por Jesucristo amen.
 * @author Deo Omnis Gloria.
 * Por la fidelidad al cuidado de la vida vencere a la muerte.
 * Licensia: puedes usar este software mientras no descuides de la dignidad de alguna persona,
 * atentes constra su libertad, vida y paz del alma, sirvas y cuides la vida de toda persona,
 * en especial a quien mas lo necesita. No cobres a quien lo necesita y no puede pagar.
 * Lo que han recibido gratis denlo gratis.
 * Quien use este software con intencion deliberada de servirse asi mismo atentando contra la
 * vida de una persona atrae maldicion y muerte para si mismo por ejercicio propio de su 
 * libertad, pue ssi rechaza a su hermano, rechaza a Dios, se rechaza a Dios, rechaza la vida
 * y el bien (Mateo 25). No borre este comentario.
 */
public class FormEntityManager {
    
    private static void generatePHPFormHeader(Table table, String libraryGetModelPath, PrintWriter out,boolean withSessionManagment){
        out.println("<?php");
        if (withSessionManagment) {
            out.println("session_start();");
            out.println("ob_start();");
            out.println("if(!isset($_SESSION['logeado'])){");
            out.println("header('Location: index.php');");
            out.println("exit();");
            out.println("}");
        }
        out.println("include_once(\""+libraryGetModelPath+StringManager.getClassName(table.getName())+".php\");");        
        for(Attribute fkatt: table.getFKAttributes()){
            out.println("include_once(\""+libraryGetModelPath+StringManager.getClassName(fkatt.getFk().getReferencedTable().getName())+".php\");");
        }
        out.println("include_once(\""+libraryGetModelPath+ValidatorGenerator.className+".php\");");

        for (Attribute attribute : table.getAttributes()) {
            //if(attribute.isAutoIncrement()) continue;
            out.println("\t$"+StringManager.getVariableName(attribute.getName())+"=null;");
        }
        out.println(""); 
        out.println("\t$"+StringManager.getVariableName(table.getName())+"=null;");
        out.println(""); 
        
        
        out.println("\tif (!empty($_POST)) {");

        for (Attribute attribute : table.getAttributes()) {
            if(attribute.isAutoIncrement()) continue;
            if(attribute.isDateTimeDomain() || attribute.isTimeStampDomain()){
                out.println("\t\t$"+StringManager.getVariableName(attribute.getName())+"Fecha= $_POST['"+StringManager.getVariableName(attribute.getName())+"Fecha'];");
                out.println("\t\t$"+StringManager.getVariableName(attribute.getName())+"Hora= $_POST['"+StringManager.getVariableName(attribute.getName())+"Hora'];");
                out.println("\t\t$"+StringManager.getVariableName(attribute.getName())+"= $"+StringManager.getVariableName(attribute.getName())+"Fecha.' '.$"+StringManager.getVariableName(attribute.getName())+"Hora.':00';");
            
            } else {
                out.println("\t\t$"+StringManager.getVariableName(attribute.getName())+"= $_POST['"+StringManager.getVariableName(attribute.getName())+"'];");
            }
        }

        String args ="";
        args ="";
        int i =0;
        for(Attribute attribute:table.getAttributes()){
            args+="$"+StringManager.getVariableName(attribute.getName());
            i++;
            if(i<table.getAttributes().size()){
                args+=",";
            }
        }
        
        out.println("\t\t$"+StringManager.getVariableName(table.getName())+
                " = new "+StringManager.getClassName(table.getName())+"("+args+");");

        // insert data
        out.println("\t\tif($"+StringManager.getVariableName(table.getName())+"->attributesAreValid()) {");        
        out.println("\t\t\t$"+StringManager.getVariableName(table.getName())+"->guardaEnBase();");
        out.println("\t\t\theader(\"Location: Reporte"+StringManager.getClassName(table.getName())+".php\");");
        out.println("\t\t} else {");
        out.println("\t\t\techo 'perdon';");
        out.println("\t\t}");
        out.println("\t}");
        
        
        out.println("?>");
    }    
    
    private static void generateJSPFormHeader(Table table,  PrintWriter out){
        out.println("<%@ page language=\"java\" contentType=\"text/html; charset=ISO-8859-1\"");
	out.println("pageEncoding=\"ISO-8859-1\"%>");
        out.println("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        out.println("<%@taglib uri=\"/struts-tags\" prefix=\"s\"%>");
        out.println("<%@taglib uri=\"/struts-jquery-tags\" prefix=\"sj\"%>");
        out.println("<html>");
        out.println("<head>");
        out.println("<sj:head />");
        out.println("<meta charset=\"utf-8\">");
        out.println("<title>Formulario de "+table.getName()+"</title>");
        out.println("<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\">");
        out.println("</head>");
        out.println("<body>");
    }
    
    private static void generateJSPFormFooter(Table table,  PrintWriter out, boolean withSessionManagment){
        out.println("</body>");
        out.println("</html>");
    }
       
    
    private static void generateJSPFormTable(Table table, PrintWriter out){
        out.println("\t\t<div align='center'>");
        out.println("");
         out.println("\t\t\t\t\t<p style=\"float: left; margin: 0px; margin-top: 8PX; margin-right: 17px; letter-spacing: 1px;\">");
        out.println("\t\t\t\t\tIntruduzca la información para dar de alta registro</p><br/><br/>");
        out.println("\t\t<s:form action=\"ejecutarAltaDatos"+StringManager.getClassName(table.getName())+"\" style=\"float:left;\" id=\"formAltaDatos"+StringManager.getClassName(table.getName())+"\">");
        out.println("");
        
        /*out.println("\t\t<s:if test=\"hasActionErrors()\">");
	out.println("\t\t<div class=\"errors\">"); 
	out.println("\t\t<s:actionerror />");
	out.println("\t\t</div>");
	out.println("\t\t</s:if>");*/
        out.println("");
        out.println("");

        out.println("\t\t\t\t<tbody>");
        out.println("\t\t\t\t\t<tr class=\"registro\">");
        out.println("\t\t\t\t\t\t<th colspan=\"2\">Alta de Registro Simple "+StringManager.getPublicLongName(table.getName())+"</th>");
        out.println("\t\t\t\t\t</tr>");
        
        for(Attribute attribute: table.getAttributes()){
            
            if(attribute.isAutoIncrement()) continue;
            
            
            
            
            if (attribute.isForeignKey()) {
                out.println("\t\t\t\t\t\t\t<tr><td>"+StringManager.getPublicLongName(attribute.getFk().getReferencedTable().getName())+"</td>");
                out.println("\t\t\t\t\t\t\t<td><select name=\"" + StringManager.getVariableName(attribute.getName()) + "\">");
                out.println("\t\t\t\t\t\t\t\t<s:iterator value=\"lista"+StringManager.getClassName(attribute.getFk().getReferencedTable().getName())+"\" status=\"indice\" var=\"e\">");
                Attribute pat= attribute.getFk().getReferencedTable().getPrimaryAttributes().get(0);        
                out.println("\t\t\t\t\t\t\t\t\t<option value=\"<s:property value=\"#e."+StringManager.getVariableName(pat.getName())+"\"/>\">");
                out.println("\t\t\t\t\t\t\t\t\t\t<s:property value=\"#e."+StringManager.getVariableName(pat.getName())+"\" />");
                out.println("\t\t\t\t\t\t\t\t\t</option>");
                out.println("\t\t\t\t\t\t\t\t</s:iterator>");
                out.println("\t\t\t\t\t\t\t</select></td>");
                out.println("\t\t\t\t\t\t\t</tr>");
                /*
                out.println("\t\t\t\t\t\t\t\t<!--");
                out.println("\t\t\t\t\t\t\t\t<s:url id=\"remoteurl\" action=\"recargar\" />");
		out.println("\t\t\t\t\t\t\t\t<sj:select href=\"%{remoteurl}\" onChangeTopics=\""+StringManager.getVariableName(attribute.getFk().getReferencedTable().getName())+"Changed\""); 
		out.println("\t\t\t\t\t\t\t\tid=\""+StringManager.getVariableName(attribute.getFk().getReferencedTable().getName())+"Select\" ");
                out.println("\t\t\t\t\t\t\t\tname=\""+StringManager.getVariableName(attribute.getFk().getReferencedTable().getName())+"\" list=\"lista"+StringManager.getClassName(attribute.getFk().getReferencedTable().getName())+"\""); 
		out.println("\t\t\t\t\t\t\t\tlistKey=\""+StringManager.getVariableName(pat.getName())+"\" listValue=\""+StringManager.getVariableName(pat.getName())+"\" headerKey=\"-1\"");
		out.println("\t\t\t\t\t\t\t\theaderValue=\"Seleccione "+StringManager.getVariableName(attribute.getFk().getReferencedTable().getName())+"\" formIds=\"formSelectReload\" />");
                out.println("\t\t\t\t\t\t\t\t-->");
     
                out.println("\t\t\t\t\t\t\t\t<!--");
                out.println("\t\t\t\t\t\t\t\t<s:iterator value=\"lista"+StringManager.getClassName(attribute.getFk().getReferencedTable().getName())+"\" status=\"indice\" var=\"e\">");
                out.println("\t\t\t\t\t\t\t\t\t<div id=\"ck-button\"");
                out.println("\t\t\t\t\t\t\t\t\t<label>");
                out.println("\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\""+ 
                        StringManager.getVariableName(attribute.getFk().getReferencedTable().getName()) +
                        "\" value=\"<s:property value=\"#e."+StringManager.getVariableName(pat.getName())+"\"/>\"  onChange=\"\"");
                out.println("\t\t\t\t\t\t\t\t\t<s:if test=\"#indice.index == 0 && #contador.index== 0\"> checked </s:if> >");
                out.println("\t\t\t\t\t\t\t\t\t<span><s:property value=\"<s:property value=\"#e."+StringManager.getVariableName(pat.getName())+"\"/>\"/></span>");
                out.println("\t\t\t\t\t\t\t\t\t</input>");
                out.println("\t\t\t\t\t\t\t\t\t</label>");
                out.println("\t\t\t\t\t\t\t\t\t</div>");
                out.println("\t\t\t\t\t\t\t\t</s:iterator>");
                out.println("\t\t\t\t\t\t\t\t-->");*/
                
                out.println("\t\t\t\t\t\t");
                
            } else {
                String lengthStr = "";
                if(!attribute.getDomainLength().equals(""))
                    lengthStr = "maxlength=\""+attribute.getDomainLength()+"\"";
                else 
                    lengthStr = "";
                out.println("\t\t\t\t\t\t\t<s:textfield label=\""+StringManager.getPublicLongName(attribute.getName())+"\" name=\""+StringManager.getVariableName(attribute.getName())+"\" value=\"%{"+StringManager.getVariableName(table.getName())+"."+StringManager.getVariableName(attribute.getName())+"}\" " + lengthStr + " />");
            }
        }
 	out.println("\t\t\t\t\t\t<s:submit value=\"Registrar\" cssClass=\"btn\" />");
        
        out.println("\t\t\t\t</tbody>");
        out.println("");
        
        out.println("\t\t</s:form>");
        out.println("");

        
        out.println("\t\t</div>");
        out.println("<br/>");

        out.println("		<s:form action=\"reporte"+StringManager.getClassName(table.getName())+"\" style=\"float:left;\" id=\"formReporte"+StringManager.getClassName(table.getName())+"\">");
        out.println("			<s:submit value=\"Cancelar\" cssClass=\"btn\" />");
        out.println("		</s:form>");
        
    }
    
    
    
    private static void generateJSPValidationJSCRIPT(Table table, PrintWriter out){
        out.println("\t\t<script>");
        out.println("\t\t\tvar cancelado = false;");
        
        for(Attribute attribute: table.getAttributes()){
            if(attribute.isAutoIncrement()) continue;
            if (attribute.isForeignKey()) {
                out.println("\t\t\t\t\t\t\t<select name=\"" + StringManager.getVariableName(attribute.getFk().getReferencedTable().getName()) + "\">");
                out.println("\t\t\t\t\t\t\t\t<s:iterator value=\"lista"+StringManager.getClassName(attribute.getFk().getReferencedTable().getName())+"\" status=\"indice\" var=\"e\">");
                Attribute pat= attribute.getFk().getReferencedTable().getPrimaryAttributes().get(0);        
                out.println("\t\t\t\t\t\t\t\t\t<option value=\"<s:property value=\"#e."+StringManager.getVariableName(pat.getName())+"\"/>\">");
                out.println("\t\t\t\t\t\t\t\t\t\t<s:property value=\"#e."+StringManager.getVariableName(pat.getName())+"\" />");
                out.println("\t\t\t\t\t\t\t\t\t</option>");
                out.println("\t\t\t\t\t\t\t\t</s:iterator>");
                out.println("\t\t\t\t\t\t\t</select>");
                
                
                out.println("\t\t\t\t\t\t\t\t<!--");
                out.println("\t\t\t\t\t\t\t\t<s:url id=\"remoteurl\" action=\"recargar\" />");
		out.println("\t\t\t\t\t\t\t\t<sj:select href=\"%{remoteurl}\" onChangeTopics=\""+StringManager.getVariableName(attribute.getFk().getReferencedTable().getName())+"Changed\""); 
		out.println("\t\t\t\t\t\t\t\tid=\""+StringManager.getVariableName(attribute.getFk().getReferencedTable().getName())+"Select\" ");
                out.println("\t\t\t\t\t\t\t\tname=\""+StringManager.getVariableName(attribute.getFk().getReferencedTable().getName())+"\" list=\"lista"+StringManager.getClassName(attribute.getFk().getReferencedTable().getName())+"\""); 
		out.println("\t\t\t\t\t\t\t\tlistKey=\""+StringManager.getVariableName(pat.getName())+"\" listValue=\""+StringManager.getVariableName(pat.getName())+"\" headerKey=\"-1\"");
		out.println("\t\t\t\t\t\t\t\theaderValue=\"Seleccione "+StringManager.getVariableName(attribute.getFk().getReferencedTable().getName())+"\" formIds=\"formSelectReload\" />");
                out.println("\t\t\t\t\t\t\t\t-->");
     
                out.println("\t\t\t\t\t\t\t\t<!--");
                out.println("\t\t\t\t\t\t\t\t<s:iterator value=\"lista"+StringManager.getClassName(attribute.getFk().getReferencedTable().getName())+"\" status=\"indice\" var=\"e\">");
                out.println("\t\t\t\t\t\t\t\t\t<div id=\"ck-button\"");
                out.println("\t\t\t\t\t\t\t\t\t<label>");
                out.println("\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\""+ 
                        StringManager.getVariableName(attribute.getFk().getReferencedTable().getName()) +
                        "\" value=\"<s:property value=\"#e."+StringManager.getVariableName(pat.getName())+"\"/>\"  onChange=\"\"");
                out.println("\t\t\t\t\t\t\t\t\t<s:if test=\"#indice.index == 0 && #contador.index== 0\"> checked </s:if> >");
                out.println("\t\t\t\t\t\t\t\t\t<span><s:property value=\"<s:property value=\"#e."+StringManager.getVariableName(pat.getName())+"\"/>\"/></span>");
                out.println("\t\t\t\t\t\t\t\t\t</input>");
                out.println("\t\t\t\t\t\t\t\t\t</label>");
                out.println("\t\t\t\t\t\t\t\t\t</div>");
                out.println("\t\t\t\t\t\t\t\t</s:iterator>");
                out.println("\t\t\t\t\t\t\t\t-->");
                
                out.println("\t\t\t\t\t\t</td>");
                
            } else {
                String lengthStr = "";
                if(!attribute.getDomainLength().equals(""))
                    lengthStr = "maxlength=\""+attribute.getDomainLength()+"\"";
                else 
                    lengthStr = "";
                out.println("\t\t\t\t\t\t\t<s:textfield name=\""+StringManager.getVariableName(attribute.getName())+"\" value=\"%{"+StringManager.getVariableName(table.getName())+"."+StringManager.getVariableName(attribute.getName())+"}\" " + lengthStr + " />");
            }
            out.println("\t\t\t\t\t\t</td></div></tr>");
        }
    
        out.println("\t\t</script>");
    }
    
    
    public static void generateJSPFormEntity(Table table,String libraryGetModelPath, String filePath, 
            boolean withSessionManagment, boolean isUnix) throws Exception{
        File file = null;
        if(isUnix){
            file = new File(filePath+ "/guadalupe/vista/"+StringManager.getClassName(table.getName())+"/Alta"+StringManager.getClassName(table.getName()) + ".jsp");
        } else {
            file = new File(filePath + "\\guadalupe\\vista\\"+StringManager.getClassName(table.getName())+"\\Alta"+StringManager.getClassName(table.getName()) + ".jsp");
        }

        
        if(!file.exists()){
            file.getParentFile().mkdirs();
        } else {
            file.delete();
            file.createNewFile();
        }
        PrintWriter out = new PrintWriter(file);
        out.println("<!--");
        Disclaimer.message(out);
        out.println("-->");
        
        //FormEntityManager.generateJSPFormHeader(table,libraryGetModelPath, out,withSessionManagment);
        FormEntityManager.generateJSPFormHeader(table, out);
        FormEntityManager.generateJSPFormTable(table, out);
        FormEntityManager.generateJSPFormFooter(table, out, withSessionManagment);
        
        out.close();
        
    }
    
    
    private static void generateSWINGForm(Table table,  PrintWriter out){
        String botones[] = {"aceptar","limpiar","cancelar","null"};
        out.println("import javax.swing.JLabel;");
        out.println("import javax.swing.JPanel;");
        out.println("import javax.swing.JTextField;");
        out.println("import javax.swing.SpringLayout;");
        out.println("import javax.swing.JButton;");
        out.println("");
        
        out.println("public class Alta"+StringManager.getClassName(table.getName())+"SWING extends javax.swing.JFrame {");

        for (Attribute attribute : table.getAttributes()) {
            out.println("\tprivate JLabel "+StringManager.getVariableName(attribute.getName())+"Label;");
            out.println("\tprivate JTextField "+StringManager.getVariableName(attribute.getName())+"TextField;");
        }

        for(int i=0;i<botones.length;i++)
            out.println("\tprivate JButton "+botones[i]+"Boton;");
        out.println(""); 
        
        out.println("\tpublic Alta"+StringManager.getClassName(table.getName())+"SWING(){");
        out.println("\t\tinitComponents();");
        out.println("\t}");
        out.println("");

        
        out.println("\t@SuppressWarnings(\"unchecked\")");
        out.println("\tprivate void initComponents() {");
        for (Attribute attribute : table.getAttributes()) {
            out.println("\t\t"+StringManager.getVariableName(attribute.getName())+"Label= new JLabel(\""+StringManager.getPublicLongName(attribute.getName())+"\", JLabel.TRAILING);");
            out.println("\t\t"+StringManager.getVariableName(attribute.getName())+"TextField= new JTextField(10);");
        }
        for(int i=0;i<botones.length;i++){
            out.println("\t\t"+botones[i]+"Boton = new JButton();");
            out.println("\t\t"+botones[i]+"Boton.setText(\""+botones[i]+"\");");
            out.println("\t\t"+botones[i]+"Boton.addActionListener(new java.awt.event.ActionListener() {");
            out.println("\t\t\tpublic void actionPerformed(java.awt.event.ActionEvent evt) {");
            out.println("\t\t\t\t"+botones[i]+"BotonActionPerformed(evt);");
            out.println("\t\t\t}");
            out.println("\t\t});");
        }
        
        
        out.println("\t\tJPanel p = new JPanel(new SpringLayout());");
        
        
        for (Attribute attribute : table.getAttributes()) {
            out.println("\t\tp.add("+StringManager.getVariableName(attribute.getName())+"Label);");            
            out.println("\t\t"+StringManager.getVariableName(attribute.getName())+"Label.setLabelFor("+StringManager.getVariableName(attribute.getName())+"TextField);");
            out.println("\t\tp.add("+StringManager.getVariableName(attribute.getName())+"TextField);");     
        }
        
        for(int i=0;i<botones.length;i++){
            out.println("\t\tp.add(this."+botones[i]+"Boton);");
        }

        out.println("\t\tSpringUtilities.makeGrid(p,");
        out.println("\t\t"+(table.getAttributes().size()+2)+", 2, //rows, cols");
        out.println("\t\t6, 6,        //initX, initY");
        out.println("\t\t6, 6);       //xPad, yPad");
 
        out.println("\t\tsetDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);");
        out.println("\t\tp.setOpaque(true);");
        out.println("\t\tsetContentPane(p);");
        out.println("\t\tpack();");
        
        out.println("\t}");
        
        out.println("");

        
        for(int i=0;i<botones.length;i++){
            out.println("\tprivate void "+botones[i]+"BotonActionPerformed(java.awt.event.ActionEvent evt) {");
            out.println("\t}");
            out.println("");

        }
        
        
        out.println("\tpublic static void main(String args[]) {");
        out.println("\t\ttry {");
        out.println("\t\t\tfor (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {");
        out.println("\t\t\tif (\"Nimbus\".equals(info.getName())) {");
        out.println("\t\t\t\tjavax.swing.UIManager.setLookAndFeel(info.getClassName());");
        out.println("\t\t\t\tbreak;");
        out.println("\t\t\t}");
        out.println("\t\t}");
        out.println("\t} catch (Exception ex) {");
        out.println("\t}");
        out.println("\tjava.awt.EventQueue.invokeLater(new Runnable() {");
        out.println("\t\tpublic void run() {");
        out.println("\t\t\tnew Alta"+StringManager.getClassName(table.getName())+"SWING().setVisible(true);");
        out.println("\t\t}");
        out.println("\t});");
        out.println("\t}");
        out.println("");

        
        out.println("}");
    }    
    
    
    public static void generateSWINGFormEntity(Table table,String libraryGetModelPath, String filePath, 
            boolean withSessionManagment, boolean isUnix) throws Exception{
        File file = null;
        if(isUnix){
            file = new File(filePath+ "/guadalupe/vista/"+StringManager.getClassName(table.getName())+"/Alta"+StringManager.getClassName(table.getName()) + "SWING.java");
        } else {
            file = new File(filePath + "\\guadalupe\\vista\\"+StringManager.getClassName(table.getName())+"\\Alta"+StringManager.getClassName(table.getName()) + "SWING.java");
        }

        
        if(!file.exists()){
            file.getParentFile().mkdirs();
        } else {
            file.delete();
            file.createNewFile();
        }
        PrintWriter out = new PrintWriter(file);
                Disclaimer.message(out);

        
        //FormEntityManager.generateJSPFormHeader(table,libraryGetModelPath, out,withSessionManagment);
        FormEntityManager.generateSWINGForm(table, out);
        out.close();
    }
    
    
    
}
