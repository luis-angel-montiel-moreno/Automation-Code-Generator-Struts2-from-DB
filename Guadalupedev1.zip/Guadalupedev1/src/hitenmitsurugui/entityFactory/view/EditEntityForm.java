package hitenmitsurugui.entityFactory.view;

import hitenmitsurugui.entityFactory.*;
import hitenmitsurugui.db.structure.Attribute;
import hitenmitsurugui.db.structure.Table;
import hitenmitsurugui.tools.StringManager;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 * Proyecto consagrado a San Jose, San Miguel Arcangel, Santa Lucía, San Expedito, Santiago 
 * e Inmacualda Concepcion por Jesucristo amen.
 * @author Deo Omnis Gloria.
 * Por la fidelidad al cuidado de la vida vencere a la muerte.
 * Licensia: puedes usar este software mientras no descuides de la dignidad de alguna persona,
 * atentes constra su libertad, vida y paz del alma, sirvas y cuides la vida de toda persona,
 * en especial a quien mas lo necesita. No cobres a quien lo necesita y no puede pagar.
 * Lo que han recibido gratis denlo gratis.
 * Quien use este software con intencion deliberada de servirse asi mismo atentando contra la
 * vida de una persona atrae maldicion y muerte para si mismo por ejercicio propio de su 
 * libertad, pue ssi rechaza a su hermano, rechaza a Dios, se rechaza a Dios, rechaza la vida
 * y el bien (Mateo 25). No borre este comentario.
 */
public class EditEntityForm {
    
    private static void generatePHPReportHeader(Table table, String libraryGetModelPath, PrintWriter out,boolean withSessionManagment){
        out.println("<?php");
        if (withSessionManagment) {
            out.println("session_start();");
            out.println("ob_start();");
            out.println("if(!isset($_SESSION['logeado'])){");
            out.println("header('Location: index.php');");
            out.println("exit();");
            out.println("}");
        }
        out.println("include_once(\""+libraryGetModelPath+StringManager.getClassName(table.getName())+".php\");");
        for(Attribute fkatt: table.getFKAttributes()){
            out.println("include_once(\""+libraryGetModelPath+StringManager.getClassName(fkatt.getFk().getReferencedTable().getName())+".php\");");
        }
        out.println("include_once(\""+libraryGetModelPath+ValidatorGenerator.className+".php\");");

        for (Attribute attribute : table.getAttributes()) {
            //if(attribute.isAutoIncrement()) continue;
            out.println("\t$"+StringManager.getVariableName(attribute.getName())+"=null;");
        }
        out.println(""); 
        out.println("\t$"+StringManager.getVariableName(table.getName())+"=null;");
        out.println(""); 
        

        String condicion ="";
        String args= "";
        String variables = "";
        int i =0;
        for(Attribute attribute:table.getPrimaryAttributes()){
            args+="$"+StringManager.getVariableName(attribute.getName());
            variables+="$"+StringManager.getVariableName(attribute.getName())+"=$_GET['"+StringManager.getVariableName(attribute.getName())+"'];\n";
            condicion+="isset($_GET['"+StringManager.getVariableName(attribute.getName())+"']) && ";
            condicion+="$_GET['"+StringManager.getVariableName(attribute.getName())+"']!=NULL";
            i++;
            if(i<table.getPrimaryAttributes().size()){
                args+=",";
                condicion+=" && ";
            }
        }
        
        out.println("if("+condicion+"){");
        out.println(variables);
        out.println("$entidad = "+StringManager.getClassName(table.getName())+"::cargaEntidadEnBase("+args+");");
        for (Attribute attribute : table.getAttributes()) {
            if(!attribute.isPrimary()) continue;
            out.println("\t$"+StringManager.getVariableName(attribute.getName())+"=$entidad->get"+StringManager.getClassName(attribute.getName())+"();");
        }
        
        
        out.println("}");
        out.println("?>");
    }    
    
    private static void generateHTMLReportHeader(Table table,  PrintWriter out){
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("\t<head>");
        out.println("\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
        out.println("\t\t<title>Registro Simple "+StringManager.getPublicLongName(table.getName())+"</title>");
        out.println("\t\t<link type=\"text/css\" rel=\"stylesheet\" href=\"../../css/chema.css\"/>");
        out.println("\t</head>");
        out.println("\t<body>");
    }
    
    private static void generateHTMLReportFooter(Table table,  PrintWriter out, boolean withSessionManagment){
        out.println("\t</body>");
        if (withSessionManagment) {
            out.println("<?php");
            out.println("ob_end_flush();");
            out.println("?>");
        }
        out.println("</html>");
    }
       
    
     private static void generatePHPFormTable(Table table, PrintWriter out){
        out.println("\t\t<div align='center'>");
        out.println("\t\t<form name=\"Registro"+StringManager.getClassName(table.getName())+"\" action=\"FormaAltaRegistro"+StringManager.getClassName(table.getName())+".php\" method=\"post\">");

        out.println("\t\t\t<table>");       
        out.println("\t\t\t\t<thead>");
        out.println("\t\t\t\t\t<tr>");
        out.println("\t\t\t\t\t\t<th colspan=\"3\">Alta de Registro Simple "+StringManager.getPublicLongName(table.getName())+"</th>");
        out.println("\t\t\t\t\t</tr>");
        
        for(Attribute attribute: table.getAttributes()){
            out.println("\t\t\t\t\t<tr>");
            out.println("\t\t\t\t\t\t<th>"+StringManager.getPublicLongName(attribute.getName())+"</th><td>");
            
             if (attribute.isForeignKey()) {
                out.println("\t\t\t\t\t\t<select name=\"" + StringManager.getVariableName(attribute.getName()) + "\">");
                out.println("\t\t\t\t\t\t<?php");
                out.println("\t\t\t\t\t\t$lista = " + StringManager.getClassName(attribute.getFk().getReferencedTable().getName()) + "::obtenEntidadesEnBase();");
                out.println("\t\t\t\t\t\tforeach($lista as $obj){");
                Attribute pat= attribute.getFk().getReferencedTable().getPrimaryAttributes().get(0);        
                out.println("\t\t\t\t\t\techo \"\t\t\t\t\t\t<option value='\".$obj->get"+StringManager.getClassName(pat.getName())+"().\"'>\".$obj->get"+StringManager.getClassName(pat.getName())+"().\"</option>\n\";");
                out.println("\t\t\t\t\t\t}");
                out.println("\t\t\t\t\t\t?>");
                out.println("\t\t\t\t\t\t</td></select>");
            } else if(attribute.isDateDomain()){
                out.println("\t\t\t\t\t\t<input type=\"date\" name=\"" + StringManager.getVariableName(attribute.getName()) + "\" value=\"<?php if(!empty($" + StringManager.getVariableName(attribute.getName()) + ")) echo $" + StringManager.getVariableName(attribute.getName()) + "; ?>\"/>");
                out.println("\t\t\t\t\t\t<?php \n\t\t\t\t\t\tif(!empty($" + StringManager.getVariableName(table.getName()) + ") && !$" + StringManager.getVariableName(table.getName()) + "->" + StringManager.getVariableName(attribute.getName()) + "IsValid()) \n\t\t\t\t\t\t\techo '<div class=\"error\">'.$" + StringManager.getVariableName(table.getName()) + "->get" + StringManager.getClassName(attribute.getName()) + "ErrorMessage().'</div>'; \n\t\t\t\t\t\t?>");            
            } else if(attribute.isDateTimeDomain() || attribute.isTimeStampDomain()){
                out.println("\t\t\t\t\t\t<input type=\"date\" name=\"" + StringManager.getVariableName(attribute.getName()) + "Fecha\" value=\"<?php if(!empty($" + StringManager.getVariableName(attribute.getName()) + "Fecha)) echo $" + StringManager.getVariableName(attribute.getName()) + "Fecha; ?>\"/>");
                out.println("\t\t\t\t\t\t<input type=\"time\" name=\"" + StringManager.getVariableName(attribute.getName()) + "Hora\" value=\"<?php if(!empty($" + StringManager.getVariableName(attribute.getName()) + "Hora)) echo $" + StringManager.getVariableName(attribute.getName()) + "Hora; ?>\"/>");
                out.println("\t\t\t\t\t\t<?php \n\t\t\t\t\t\tif(!empty($" + StringManager.getVariableName(table.getName()) + ") && !$" + StringManager.getVariableName(table.getName()) + "->" + StringManager.getVariableName(attribute.getName()) + "IsValid()) \n\t\t\t\t\t\t\techo '<div class=\"error\">'.$" + StringManager.getVariableName(table.getName()) + "->get" + StringManager.getClassName(attribute.getName()) + "ErrorMessage().'</div>'; \n\t\t\t\t\t\t?>");            
            } else {
                out.println("\t\t\t\t\t\t<input type=\"text\" name=\"" + StringManager.getVariableName(attribute.getName()) + "\" value=\"<?php if(!empty($" + StringManager.getVariableName(attribute.getName()) + ")) echo $" + StringManager.getVariableName(attribute.getName()) + "; ?>\"/>");
                out.println("\t\t\t\t\t\t<?php \n\t\t\t\t\t\tif(!empty($" + StringManager.getVariableName(table.getName()) + ") && !$" + StringManager.getVariableName(table.getName()) + "->" + StringManager.getVariableName(attribute.getName()) + "IsValid()) \n\t\t\t\t\t\t\techo '<div class=\"error\">'.$" + StringManager.getVariableName(table.getName()) + "->get" + StringManager.getClassName(attribute.getName()) + "ErrorMessage().'</div>'; \n\t\t\t\t\t\t?>");
            }

             
            out.println("\t\t\t\t\t<td></tr>");
        }
        
        out.println("\t\t\t\t\t<tr>");
	out.println("\t\t\t\t\t\t<th>&nbsp;</th><td><input type=\"submit\" name=\"guardar\" value=\"guardar\"/> </td><td/>");			
	out.println("\t\t\t\t\t</tr>");
        out.println("\t\t\t\t</thead>");
        out.println("\t\t\t</table>");
        
        out.println("\t\t</form>");
        out.println("\t\t</div>");
    }
    
    public static void generatePHPReport(Table table,String libraryGetModelPath, String filePath, 
            boolean withSessionManagment,boolean isUnix) throws Exception{
        File file = null;
        if(isUnix){
            file = new File(filePath + "/guadalupe/vista/"+StringManager.getClassName(table.getName())+"/ModificaRegistro"+StringManager.getClassName(table.getName()) + ".php");
        } else {
            file = new File(filePath + "\\guadalupe\\vista\\"+StringManager.getClassName(table.getName())+"\\ModificaRegistro"+StringManager.getClassName(table.getName()) + ".php");
        }

        
        if(!file.exists()){
            file.getParentFile().mkdirs();
        } else {
            file.delete();
            file.createNewFile();
        }
        PrintWriter out = new PrintWriter(file);
        
        EditEntityForm.generatePHPReportHeader(table,libraryGetModelPath, out,withSessionManagment);
        EditEntityForm.generateHTMLReportHeader(table, out);
        EditEntityForm.generatePHPFormTable(table, out);
        EditEntityForm.generateHTMLReportFooter(table, out, withSessionManagment);
        
        out.close();
        
    }
    
}
