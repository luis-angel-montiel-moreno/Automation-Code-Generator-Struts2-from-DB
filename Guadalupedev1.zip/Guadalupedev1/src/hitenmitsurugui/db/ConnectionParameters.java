/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hitenmitsurugui.db;

/**
 *
 * @author ACER
 */
public class ConnectionParameters {
    private String user;
    private String password;
    private String dbName;
    private String hosting;
    private String port;

    public ConnectionParameters(String user, String password, String dbName, String hosting, String port) {
        this.user = user;
        this.password = password;
        this.dbName = dbName;
        this.hosting = hosting;
        this.port = port;
    }

    public ConnectionParameters() {
        this.user = "";
        this.password = "";
        this.dbName = "";
        this.hosting = "";
        this.port = "";
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDbName() {
        return dbName;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    public String getHosting() {
        return hosting;
    }

    public void setHosting(String hosting) {
        this.hosting = hosting;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    @Override
    public String toString() {
        return "ConnectionParameters{" + "user=" + user + ", password=" + password + ", dbName=" + dbName + ", hosting=" + hosting + ", port=" + port + '}';
    }
    
    
    
    
    
}
