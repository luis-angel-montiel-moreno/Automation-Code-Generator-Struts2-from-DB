/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package x;

/**
 *
 * @author Getsemaní
 */
public class X {
/*
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@taglib uri="/struts-tags" prefix="s"%>
<%@taglib uri="/struts-jquery-tags" prefix="sj"%>
<html>
<head>
<sj:head />
<meta charset="utf-8">
<title>Formulario de Tutorado</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="logo_alumno">
		<img src="images/etapa1.png"
			style="width: 110%; display: block; margin-left: auto; margin-right: auto;">
	</div>
	<div class="linea_tiempo">
		<img src="images/fase1.png"
			style="width: 50%; display: block; margin-left: auto; margin-right: auto;">
	</div>
	<div class="navegacion">
		<div class="navigator" align="center">
			Bienvenido Madre, Padre o tutor del alumno/a
			<s:property value="alumno.nombre" />
			<s:property value="alumno.apellidoPaterno" />
			<s:property value="alumno.apellidoMaterno" />, al Sistema de Inscripción Anticipada en Línea, por favor verifique los datos, si es necesario, actualícelos.
		</div>
		<table width="400" border="0" align="center" class="alumnos_">
			<tbody>
				<tr class="registro">
					<td class="text"><div class="text">Nombre del Alumno</div></td>
					<td class="content_table"><s:property
							value="alumno.apellidoPaterno" /> <s:property
							value="alumno.apellidoMaterno" /> <s:property
							value="alumno.nombre" /></td>
				</tr>
				<tr class="registro">
					<td class="text">
						<div>Fecha de Nacimiento</div>
					</td>
					<td class="content_table"><s:property
							value="alumno.fechaNacimiento" /></td>
				</tr>
				<tr class="registro">
					<td class="text"><div>CURP</div></td>
					<td class="content_table"><s:property value="alumno.curp" /></td>
				</tr>
				<tr class="registro">
					<td class="text"><div>NIA</div></td>
					<td class="content_table"><s:property value="alumno.nia" /></td>
				</tr>
				<tr class="registro">
					<td class="text"><div>Discapacidad</div></td>
					<td class="content_table"><s:property
							value="alumno.discapacidad.nombre" /></td>
				</tr>
				<tr class="registro">
					<td class="text"><div>Domicilio del alumno</div></td>
					<td class="content_table"><s:if
							test="alumno.sinDireccion == true">
				Sin Domicilio
				</s:if> <s:else>
							<s:property value="alumno.direccion.calle" />
							<s:property value="alumno.direccion.numeroExterior" />
							<s:property value="alumno.direccion.asentamiento.nombre" />
							<s:property value="alumno.direccion.municipio.nombre" />
							<s:property value="alumno.direccion.localidad.nombre" />
							<s:property value="alumno.direccion.coloniaCP" />
						</s:else></td>
				</tr>
				<tr class="registro">
					<td class="text"><div>Nombre de la Escuela</div></td>
					<td class="content_table"><s:property
							value="alumno.asignacionEscuela.escuela.nombre" /></td>
				</tr>
				<tr class="registro">
					<td class="text"><div>Ciclo Escolar</div></td>
					<td class="content_table"><s:property
							value="alumno.cicloEscolar.nombre" /></td>
				</tr>
				<tr class="registro">
					<td class="text"><div>Grado</div></td>
					<td class="content_table"><s:property
							value="alumno.asignacionEscuela.gradoNombre" /></td>
				</tr>
				<tr class="registro">
					<td class="text"><div>Turno</div></td>
					<td class="content_table"><s:property
							value="alumno.asignacionEscuela.turnoNombre" /></td>
				</tr>
				<tr class="registro">
					<td class="text"><div>Nombre del Tutor</div></td>
					<td class="content_table"><s:if test="alumno.sinTutor == true">
				Sin Tutor
				</s:if> <s:else>
							<s:property value="persona.nombre" />
							<s:property value="persona.apellidoPaterno" />
							<s:property value="persona.apellidoMaterno" />
						</s:else></td>
				</tr>
				<tr class="registro">
					<td class="text"><div>Correo Electrónico</div></td>
					<td class="content_table"><s:property value="persona.email" />
				</tr>
				<tr class="registro">
					<td class="text"><div>Teléfono</div></td>
					<td class="content_table"><s:property value="persona.telefono" />
				</tr>
				<tr class="registro">
					<td class="text"><div>Hermanos:</div> </td>
					<td class="content_table">
						<table> 
						<tr><td>
						<div>
						¿El alumno a inscribir tiene hermanos en primaria / secundaria pública? Ingresa su NIA.
						<br/>
						<a href="#" id="addNew">Agregar Hermano</a>
						<br/>
						</div>
						</td>
						</tr>
						<tr>
						<td>
						<div>
						<s:form action="fratelli" style="float: left;">
						
							<div id="addinput">
							<s:if test="niasHermanosConError!=null && niasHermanosConError.size > 0">
								<s:iterator value="niasHermanosConError" status="indice" var="niaHermano">
										<p><label for="hermano">NIA HERMANO:</label><input id="hermano" type="text" name="hermano" size="15" value="<s:property value="#niaHermano"/>"/>
											<a href="#" id="remNew">Cancelar</a>
											<br>
											<s:property value="%{mensajeErrorHermano.get(#indice.index)}"/>
										</p>
								</s:iterator>
							</s:if>
							
							</div>
							<div id="addbotoninput">
								<s:if test="niasHermanosConError!=null && niasHermanosConError.size > 0">
									<input type="submit" id="hermano" value="Registra Hermanos" class="btn"/>
								</s:if>
							</div>
						</s:form>
						</div>
						</td>
						</tr>
						<tr>
						<td>
						<s:if test="hermanos!=null && hermanos.size > 0">
							
							<div>
								Hermanos Registrados:<br/>
							<table border="0" cellspacing="0" cellpadding="1"  class ="tabla_maps">
								<tr class="registro" id="text_escuela">
                            	<td width="8%">NIA</td> 
                                <td width="55%">Nombre</td>
                                <td width="15%">CCT</td>
                            	</tr>
								
								<s:iterator value="hermanos" status="indice" var="bro">
								
									<tr class="registro">
										<td style=" border-left: 1px solid #0A599E;"><s:property value="#bro.hermano_nia"/></td>
										<td><s:property value="#bro.nombre"/>
											<s:property value="#bro.apellido_paterno"/>
											<s:property value="#bro.apellido_materno"/>
										</td>
										<td><s:property value="#bro.cct"/></td>
									</tr>
								</s:iterator>									
								</tbody>
							</table>
							</div>
						</s:if>
						</td></tr>
						</table>
						
					</td>
				</tr>
				
				
			</tbody>
		</table>
		<br>
		<div class="boton">
			<p
				style="float: left; margin: 0px; margin-top: 8PX; margin-right: 17px; letter-spacing: 1px;">
				¿Son correctos tus datos?</p>
			<s:form action="actualizarDatos" style="float: left;">
				<s:hidden name="idTutor" value="%{persona.id}" />
				<s:submit name="botonAceptar" value="Sí" action="solicitarInscripcionAnticipada"
					cssClass="btn" onclick="validaNiasHermanos();return false;" />
				<s:submit value="No" cssClass="btn" />
			</s:form>
		</div>
</body>
</html>

*/    
}
