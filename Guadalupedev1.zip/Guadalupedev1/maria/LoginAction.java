package mx.com.profeti.spisep.action;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import mx.com.profeti.spisep.dao.AlumnoDAO;
import mx.com.profeti.spisep.dao.UsuarioDAO;
import mx.com.profeti.spisep.dao.geo.HermanoDAO;
import mx.com.profeti.spisep.dao.geo.PreeinscripcionDAO;
import mx.com.profeti.spisep.model.Alumno;
import mx.com.profeti.spisep.model.DatosCabecera;
import mx.com.profeti.spisep.model.Persona;
import mx.com.profeti.spisep.model.basico.EstatusAsignacion;
import mx.com.profeti.spisep.model.basico.Hermano;
import mx.com.profeti.spisep.model.basico.Preeinscripcion;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.json.JSONObject;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
	static Logger log = Logger.getLogger(LoginAction.class.getName());
	private String nia;
	private String curp;
	private String kaptcha;
	private boolean aceptoAviso;
	private UsuarioDAO usuarioDAO = new UsuarioDAO();
	private AlumnoDAO alumnoDAO = new AlumnoDAO();
	private Persona persona;
	private Alumno alumno;
	
	private List<Hermano> hermanos;

	public String getKaptcha() {
		return kaptcha;
	}

	public void setKaptcha(String kaptcha) {
		this.kaptcha = kaptcha;
	}

	public String getNia() {
		return nia;
	}

	public void setNia(String nia) {
		this.nia = nia;
	}

	public String getCurp() {
		return curp;
	}

	public void setCurp(String curp) {
		this.curp = curp;
	}

	public boolean isAceptoAviso() {
		return aceptoAviso;
	}

	public void setAceptoAviso(boolean aceptoAviso) {
		this.aceptoAviso = aceptoAviso;
	}

	public List<Hermano> getHermanos() {
		return hermanos;
	}

	public void setHermanos(List<Hermano> hermanos) {
		this.hermanos = hermanos;
	}

	@Override
	public String execute() throws Exception {
		if (usuarioDAO.validar(nia, curp)) {
			String kaptchaExpected = (String) ActionContext.getContext()
					.getSession()
					.get(com.google.code.kaptcha.Constants.KAPTCHA_SESSION_KEY);

			if (kaptcha == null || !kaptcha.equalsIgnoreCase(kaptchaExpected)) {
				addActionError("Captcha incorrecto");
				return ERROR;
			} else {
				Map session = ActionContext.getContext().getSession();
				session.put("logined", "true");
				session.put("context", new Date());

				persona = usuarioDAO.getPersona(nia, curp);
				alumno = alumnoDAO.getAlumnoByTutor(persona);

				if (alumno == null) {
					addActionError("El alumno no se encuentra asignado a ninguna escuela");
					return ERROR;
				}

				session.put("persona", persona);
				
				hermanos = HermanoDAO.getHermanos(alumno.getNia());
				session.put("hermanos", hermanos);
				log.fatal(hermanos);
				

				if (session.containsKey("sesionDuplicada")) {
					session.remove("sesionDuplicada");
					addActionError("Ya ha ingresado y la sesi�n se encuentra iniciada");
					return ERROR;
				}

				session.put("inactividadSeccion",
						getText("seccion.actualizacion.inactividad"));
				session.put("advertenciaInactividad",
						getText("advertencia.inactividad"));

				DatosCabecera datosCabecera = new DatosCabecera();
				datosCabecera.setNombreAlumno(alumno.getNombre() + " "
						+ alumno.getApellidoPaterno() + " "
						+ alumno.getApellidoMaterno());
				datosCabecera.setNia(alumno.getNia());
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String fecha = sdf.format(new Date());
				datosCabecera.setFecha(fecha);

				session.put("datosCabecera", datosCabecera);

				PreeinscripcionDAO pdao = new PreeinscripcionDAO();

				Preeinscripcion pins = new Preeinscripcion();
				List<Preeinscripcion> plist = PreeinscripcionDAO
						.getPreeinscripciones(alumno.getNia());

				if (plist == null || plist.size() == 0) {
					pins.setAlumno_nia(alumno.getNia());
					pins.setAsignacion_escuela_id(0);
					pins.setObservaciones("Login");
					Date now = new Date();

					pins.setCreateTime(now);
					pins.setUpdateTime(now);
					pins.setActivo(1);

					EstatusAsignacion estatus = new EstatusAsignacion();
					estatus.setId(1); // ojo aqui revisar cual es el
										// indicado. 1.

					pins.setEstatusAsignacion(estatus);
					pins.setTipoRegistro(Preeinscripcion.TIPO_REGISTRO_LOGIN);
					pdao.insertaPreeinscripcion(pins);
				} else {
					pins = plist.get(0);

					int estatusAsignacionId = pins.getEstatusAsignacion()
							.getId();
					String tipoRegistro = pins.getTipoRegistro();

					if (estatusAsignacionId == 3) {
						return tipoRegistro;
					}
				}

				return SUCCESS;
			}
		} else {
			addActionError("NIA � CURP incorrectos");
			return ERROR;
		}
	}

	private boolean isCaptchaCorrecto() throws Exception {
		boolean isCaptchaCorrecto = false;
		HttpServletRequest request = ServletActionContext.getRequest();
		String url = "https://www.google.com/recaptcha/api/siteverify?secret=6Lfr5f4SAAAAAGFqGbtyjxW_Vd57nCk5jn_RtZyD&response="
				+ request.getParameter("g-recaptcha-response");
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		int responseCode = con.getResponseCode();
		BufferedReader in = new BufferedReader(new InputStreamReader(
				con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		isCaptchaCorrecto = new JSONObject(response.toString())
				.getBoolean("success");

		return isCaptchaCorrecto;
	}

	public String recargarCaptcha() {
		return SUCCESS;
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	public Alumno getAlumno() {
		return alumno;
	}

	public void setAlumno(Alumno alumno) {
		this.alumno = alumno;
	}

}
