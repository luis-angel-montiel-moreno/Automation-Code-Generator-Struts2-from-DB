package mx.com.profeti.spisep.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import mx.com.profeti.spisep.dao.AlumnoDAO;
import mx.com.profeti.spisep.dao.AsentamientoDAO;
import mx.com.profeti.spisep.dao.CodigoPostalDAO;
import mx.com.profeti.spisep.dao.DiscapacidadDAO;
import mx.com.profeti.spisep.dao.LocalidadDAO;
import mx.com.profeti.spisep.dao.MunicipioDAO;
import mx.com.profeti.spisep.dao.PersonaDAO;
import mx.com.profeti.spisep.model.Alumno;
import mx.com.profeti.spisep.model.Asentamiento;
import mx.com.profeti.spisep.model.Discapacidad;
import mx.com.profeti.spisep.model.Localidad;
import mx.com.profeti.spisep.model.Municipio;
import mx.com.profeti.spisep.model.Persona;
import mx.com.profeti.spisep.model.basico.CodigoPostal;
import mx.com.profeti.spisep.model.basico.Hermano;
import mx.com.profeti.spisep.validator.EmailValidator;

import org.apache.log4j.Logger;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

public class ActualizarAction extends ActionSupport implements Preparable {
	static Logger log = Logger.getLogger(ActualizarAction.class.getName());
	private AlumnoDAO alumnoDAO = new AlumnoDAO();
	private DiscapacidadDAO discapacidadDAO = new DiscapacidadDAO();
	private MunicipioDAO municipioDAO = new MunicipioDAO();
	private LocalidadDAO localidadDAO = new LocalidadDAO();
	private AsentamientoDAO asentamientoDAO = new AsentamientoDAO();
	private CodigoPostalDAO codigoPostalDAO = new CodigoPostalDAO();
	private PersonaDAO personaDAO = new PersonaDAO();
	private Persona persona;
	private Alumno alumno;
	private int idTutor;
	private ArrayList<Discapacidad> discapacidadList;
	private List<Municipio> municipioList;
	private ArrayList<Localidad> localidadList;
	private ArrayList<Asentamiento> asentamientoList;
	private ArrayList<CodigoPostal> codigoPostalList;
	private int discapacidad;
	private int municipio;
	private int localidad;
	private int asentamiento;
	private String calle;
	private String numeroExterior;
	private String numeroInterior;
	private int codigoPostal;
	private String email;
	private String telefono;
	
	private List<Hermano> hermanos;
	
	public List<Hermano> getHermanos() {
		return hermanos;
	}

	

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String mostrarBuscarEscuelas() {
		return "selector";
	}	

	public String actualizarDatos() throws Exception {
		Map session = ActionContext.getContext().getSession();
		persona = (Persona) session.get("persona");
		alumno = alumnoDAO.getAlumnoByTutor(persona);
		discapacidadList = discapacidadDAO.getDiscapacidadList();
		municipio = alumno.getDireccion().getMunicipio().getId();
		localidad = alumno.getDireccion().getLocalidad().getId();
		asentamiento = alumno.getDireccion().getAsentamiento().getId();
		codigoPostal = alumno.getDireccion().getColoniaCP();
		email = persona.getEmail();
		telefono = persona.getTelefono();
		
		session.put("municipio", municipio);

		return SUCCESS;
	}
	
	public String cancelarActualizarDatos() {
		return SUCCESS;
	}

	public String ejecutarActualizarDatos() throws Exception {
		
		boolean hasErrors = false;
		
		
		if (calle == null) {
			return null;
		}
		if (calle != null && calle.length() == 0) {
			addActionError("Por favor introduzca la calle");
			hasErrors = true;
		}
		if (numeroExterior != null && numeroExterior.length() == 0) {
			addActionError("Por favor introduzca el n�mero exterior");
			hasErrors = true;
		}
		if (municipio == -1) {
			addActionError("Por favor introduzca el municipio");
			hasErrors = true;
		}
		if (localidad == -1) {
			addActionError("Por favor introduzca la localidad");
			hasErrors = true;
		}
		if (asentamiento == -1) {
			addActionError("Por favor introduzca la colonia");
			hasErrors = true;
		}
		if (codigoPostal == -1) {
			addActionError("Por favor introduzca el c�digo postal");
			hasErrors = true;
		}
		
		EmailValidator emailValidator = new EmailValidator();
		if (!emailValidator.validate(email)) {
			addActionError("Por favor introduzca un correo electr�nico v�lido");
			hasErrors = true;
		}
		
		if (hasErrors) {
			return ERROR;
		}

		Map session = ActionContext.getContext().getSession();
		persona = (Persona) session.get("persona");
		alumno = alumnoDAO.getAlumnoByTutor(persona);

		alumno.getDiscapacidad().setId(discapacidad);
		alumno.getDireccion().setCalle(calle);
		alumno.getDireccion().setNumeroExterior(numeroExterior);
		alumno.getDireccion().setNumeroInterior(numeroInterior);
		alumno.getDireccion().setColoniaCP(codigoPostal);
		alumno.getDireccion().getMunicipio().setId(municipio);
		alumno.getDireccion().getLocalidad().setId(localidad);
		alumno.getDireccion().getAsentamiento().setId(asentamiento);
		persona.setEmail(email);
		persona.setTelefono(telefono);

		alumnoDAO.actualizarDiscapacidad(alumno);
		alumnoDAO.actualizarDireccion(alumno.getDireccion());
		personaDAO.actualizarPersona(persona);

		alumno = alumnoDAO.getAlumnoByTutor(persona);

		return SUCCESS;
	}

	public String recargarLocalidad() throws Exception {
		Map session = ActionContext.getContext().getSession();
		if (municipio != 0) {
			session.put("municipio", municipio);
		}
		if (localidad != 0) {
			session.put("localidad", localidad);
		}
		municipioList = municipioDAO.getMunicipioList();
		localidadList = localidadDAO.getLocalidadList(municipio);
		asentamientoList = asentamientoDAO.getAsentamientoList(municipio, false);
		codigoPostalList = codigoPostalDAO.getCodigoPostalList(municipio);

		return SUCCESS;
	}

	public String getJSON() throws Exception {
		return recargarLocalidad();
	}

	@Override
	public void prepare() throws Exception {
		Map session = ActionContext.getContext().getSession();
		persona = (Persona) session.get("persona");
		alumno = alumnoDAO.getAlumnoByTutor(persona);
		hermanos = (List<Hermano>) session.get("hermanos");
		if (session.containsKey("municipio")) {
			municipio = (int) session.get("municipio");
		}
		//localidad = (int) session.get("localidad");
		discapacidadList = discapacidadDAO.getDiscapacidadList();
		municipioList = municipioDAO.getMunicipioList();
		localidadList = localidadDAO.getLocalidadList(municipio);
		asentamientoList = asentamientoDAO.getAsentamientoList(municipio, false);
		codigoPostalList = codigoPostalDAO.getCodigoPostalList(municipio);
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	public Alumno getAlumno() {
		return alumno;
	}

	public void setAlumno(Alumno alumno) {
		this.alumno = alumno;
	}

	public int getIdTutor() {
		return idTutor;
	}

	public void setIdTutor(int idTutor) {
		this.idTutor = idTutor;
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public String getNumeroExterior() {
		return numeroExterior;
	}

	public void setNumeroExterior(String numeroExterior) {
		this.numeroExterior = numeroExterior;
	}

	public String getNumeroInterior() {
		return numeroInterior;
	}

	public void setNumeroInterior(String numeroInterior) {
		this.numeroInterior = numeroInterior;
	}

	public ArrayList<Discapacidad> getDiscapacidadList() {
		return discapacidadList;
	}

	public void setDiscapacidadList(ArrayList<Discapacidad> discapacidadList) {
		this.discapacidadList = discapacidadList;
	}

	public int getDiscapacidad() {
		return discapacidad;
	}

	public void setDiscapacidad(int discapacidad) {
		this.discapacidad = discapacidad;
	}

	public List<Municipio> getMunicipioList() {
		return municipioList;
	}

	public void setMunicipioList(ArrayList<Municipio> municipioList) {
		this.municipioList = municipioList;
	}

	public ArrayList<Localidad> getLocalidadList() {
		return localidadList;
	}

	public void setLocalidadList(ArrayList<Localidad> localidadList) {
		this.localidadList = localidadList;
	}

	public int getMunicipio() {
		return municipio;
	}

	public void setMunicipio(int municipio) {
		this.municipio = municipio;
	}

	public int getLocalidad() {
		return localidad;
	}

	public void setLocalidad(int localidad) {
		this.localidad = localidad;
	}

	public ArrayList<Asentamiento> getAsentamientoList() {
		return asentamientoList;
	}

	public void setAsentamientoList(ArrayList<Asentamiento> asentamientoList) {
		this.asentamientoList = asentamientoList;
	}

	public int getAsentamiento() {
		return asentamiento;
	}

	public void setAsentamiento(int asentamiento) {
		this.asentamiento = asentamiento;
	}

	public ArrayList<CodigoPostal> getCodigoPostalList() {
		return codigoPostalList;
	}

	public void setCodigoPostalList(ArrayList<CodigoPostal> codigoPostalList) {
		this.codigoPostalList = codigoPostalList;
	}

	public int getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(int codigoPostal) {
		this.codigoPostal = codigoPostal;
	}
}
