package guadalupe.util;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Proyecto consagrado a San Jose, San Miguel Arcangel, Santa Lucía, San Expedito, Santiago 
 * e Inmacualda Concepcion por Jesucristo amen.
 * @author Deo Omnis Gloria.
 * Por la fidelidad al cuidado de la vida vencere a la muerte.
 * Licensia: puedes usar este software mientras no descuides de la dignidad de alguna persona,
 * atentes constra su libertad, vida y paz del alma, sirvas y cuides la vida de toda persona,
 * en especial a quien mas lo necesita. No cobres a quien lo necesita y no puede pagar.
 * Lo que han recibido gratis denlo gratis.
 * Quien use este software con intencion deliberada de servirse asi mismo atentando contra la
 * vida de una persona atrae maldicion y muerte para si mismo por ejercicio propio de su 
 * libertad, pue ssi rechaza a su hermano, rechaza a Dios, se rechaza a Dios, rechaza la vida
 * y el bien (Mateo 25). No borre este comentario. 
 */
public class DBManager {
    private String user;
    private String password;
    private String dbName;
    private String hosting;
    private String port;
    private String url;

    public DBManager(String user, String password, String dbName, String hosting, String port) {
        this.user = user;
        this.password = password;
        this.dbName = dbName;
        this.hosting = hosting;
        this.port = port;
    }
    

    
    
    public Connection connect() throws ClassNotFoundException, SQLException{
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            throw new ClassNotFoundException("Error al configurar driver:"+ex);
        }
        setURL();
        try {
            con = (Connection)DriverManager.getConnection(url, user,password);
        } catch (SQLException ex) {
            throw new SQLException("Error al abrir conexion:"+ex);
        }
        return con;
    }
    
    
    public void disconnect(Connection con) throws Exception{
        try {
            con.close();
        } catch (Exception ex) {
            throw new Exception("Error al cerrar statements:"+ex);
        } finally {
            if(con!=null) try {
                con.close();
            } catch (Exception ex) {
                throw new Exception("Error al cerrar conexion:"+ex);
            }
        }
    }
    
    public void setUser(String user) {
        this.user = user;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    public void setHosting(String hosting) {
        this.hosting = hosting;
    }

    public void setPort(String port) {
        this.port = port;
    }
    
    
    public void setURL() throws SQLException{
        if(hosting.equals("")){
            throw new SQLException("Error al definir URL de conexion.");
        }
        
        if(port == null || !port.equals("")){
            url = "jdbc:mysql://"+hosting+":"+port+"/"+dbName;
        } else {
            url = "jdbc:mysql://"+hosting+"/"+dbName;
        }
        
    }
    
    public ConnectionParameters getConnectionParameters(){
        return new ConnectionParameters(user, password,  dbName, hosting, port);
    }
    
    
}
