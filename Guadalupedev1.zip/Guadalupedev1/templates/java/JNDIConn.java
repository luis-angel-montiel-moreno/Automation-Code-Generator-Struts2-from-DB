package guadalupe.util;

import java.sql.Connection;
import javax.naming.*;
import javax.sql.DataSource;

public class JNDIConn {

	public Connection getConn() {
		Connection conn = null;
		try {
			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource) ctx
					.lookup("jdbc/guadalupe");
			conn = ds.getConnection();

		} catch (Exception ex) {
			System.out.println(ex);
			return null;
		}
		return conn;
	}
}
